@echo off
setlocal
set GRADLE_VERSION=8.10.2
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle %*
  exit /b %errorlevel%
)
echo Gradle is not installed. Install Gradle %GRADLE_VERSION% or open the project in Android Studio.
exit /b 1
