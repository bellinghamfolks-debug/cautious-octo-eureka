# بناء APK بدون Android Studio

هذا المشروع مجهز للبناء عبر GitHub Actions أو Codemagic.

## الخيار الأول: Codemagic
إذا ظهرت لك خانة:

The root directory of your Android project

اكتب فقط:

AccessibleTapHelper

لا تكتب نقطة في البداية، ولا تكتب ./AccessibleTapHelper.

إذا سأل:

Does your app use Kotlin build scripts?

اختر:

No

أمر البناء:

./gradlew :app:assembleDebug --no-daemon

مكان APK بعد اكتمال البناء:

app/build/outputs/apk/debug/app-debug.apk

## الخيار الثاني: GitHub Actions
ارفع محتويات مجلد AccessibleTapHelper إلى مستودع GitHub، ثم ادخل إلى Actions وشغّل Build APK.

إذا رفعت المجلد الخارجي كاملًا، أضفت لك ملف Workflow خارجي أيضًا يحاول البناء من داخل مجلد AccessibleTapHelper.

## ملاحظة عن ملف gradlew
أضفت ملف gradlew مخصصًا؛ إذا لم يجد Gradle في بيئة البناء، ينزّل Gradle 8.10.2 تلقائيًا ثم يبني المشروع.
