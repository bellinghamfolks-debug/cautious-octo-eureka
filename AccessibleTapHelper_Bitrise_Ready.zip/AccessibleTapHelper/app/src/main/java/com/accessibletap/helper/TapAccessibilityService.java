package com.accessibletap.helper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class TapAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean gestureBusy = false;
    private int completedCycles = 0;
    private BroadcastReceiver receiver;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
            int maxCycles = prefs.getInt(MainActivity.KEY_MAX, 20);
            if (completedCycles >= maxCycles) {
                stopRunning("تم الإيقاف تلقائيًا بعد الوصول إلى العدد المحدد");
                return;
            }
            if (!gestureBusy) {
                performTapThenMaybeScroll(true);
                completedCycles++;
            }
            int interval = clamp(prefs.getInt(MainActivity.KEY_INTERVAL, 2500), 1200, 10000);
            handler.postDelayed(this, interval);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }
        registerCommandReceiver();
        toast("خدمة مساعد النقر جاهزة. زر رفع الصوت يبدأ أو يوقف. زر خفض الصوت يوقف فورًا.");
    }

    private void registerCommandReceiver() {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getAction() == null) return;
                String action = intent.getAction();
                if (MainActivity.ACTION_START.equals(action)) {
                    startRunning();
                } else if (MainActivity.ACTION_STOP.equals(action)) {
                    stopRunning("تم الإيقاف");
                } else if (MainActivity.ACTION_SINGLE.equals(action)) {
                    runSingleCycle();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(MainActivity.ACTION_START);
        filter.addAction(MainActivity.ACTION_STOP);
        filter.addAction(MainActivity.ACTION_SINGLE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, filter);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // التطبيق لا يحتاج قراءة محتوى الشاشة. يعمل فقط على تنفيذ إيماءات يحددها المستخدم.
    }

    @Override
    public void onInterrupt() {
        stopRunning("تمت مقاطعة الخدمة");
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() != KeyEvent.ACTION_UP) return false;
        int code = event.getKeyCode();
        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (running) {
                stopRunning("تم الإيقاف بزر رفع الصوت");
            } else {
                startRunning();
            }
            return true;
        }
        if (code == KeyEvent.KEYCODE_VOLUME_DOWN) {
            stopRunning("تم الإيقاف بزر خفض الصوت");
            return true;
        }
        return false;
    }

    private void startRunning() {
        completedCycles = 0;
        running = true;
        handler.removeCallbacks(loop);
        toast("بدأ التشغيل المتكرر");
        handler.post(loop);
    }

    private void runSingleCycle() {
        if (gestureBusy) {
            toast("انتظر انتهاء الإيماءة الحالية");
            return;
        }
        toast("تنفيذ دورة واحدة");
        performTapThenMaybeScroll(false);
    }

    private void stopRunning(String message) {
        running = false;
        handler.removeCallbacks(loop);
        gestureBusy = false;
        toast(message);
    }

    private void performTapThenMaybeScroll(boolean partOfLoop) {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        int xPercent = clamp(prefs.getInt(MainActivity.KEY_X, 50), 0, 100);
        int yPercent = clamp(prefs.getInt(MainActivity.KEY_Y, 82), 0, 100);
        boolean scrollEnabled = prefs.getBoolean(MainActivity.KEY_SCROLL, true);

        int[] size = getScreenSize();
        int x = clamp(Math.round(size[0] * (xPercent / 100f)), 1, Math.max(1, size[0] - 1));
        int y = clamp(Math.round(size[1] * (yPercent / 100f)), 1, Math.max(1, size[1] - 1));

        gestureBusy = true;
        Path tapPath = new Path();
        tapPath.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(tapPath, 0, 80));
        dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                if (scrollEnabled && (running || !partOfLoop)) {
                    handler.postDelayed(() -> performScroll(size), 280);
                } else {
                    gestureBusy = false;
                }
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                gestureBusy = false;
            }
        }, handler);
    }

    private void performScroll(int[] size) {
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        int w = size[0];
        int h = size[1];
        int x = Math.max(1, w / 2);
        int startPercent = clamp(prefs.getInt(MainActivity.KEY_SWIPE_START, 78), 0, 100);
        int endPercent = clamp(prefs.getInt(MainActivity.KEY_SWIPE_END, 35), 0, 100);
        if (startPercent <= endPercent) {
            startPercent = 78;
            endPercent = 35;
        }
        int startY = clamp(Math.round(h * (startPercent / 100f)), 1, Math.max(1, h - 1));
        int endY = clamp(Math.round(h * (endPercent / 100f)), 1, Math.max(1, h - 1));

        Path swipePath = new Path();
        swipePath.moveTo(x, startY);
        swipePath.lineTo(x, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(swipePath, 0, 450));
        dispatchGesture(builder.build(), new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                gestureBusy = false;
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                gestureBusy = false;
            }
        }, handler);
    }

    private int[] getScreenSize() {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm != null) {
            if (Build.VERSION.SDK_INT >= 30) {
                metrics = getResources().getDisplayMetrics();
            } else {
                wm.getDefaultDisplay().getRealMetrics(metrics);
            }
        } else {
            metrics = getResources().getDisplayMetrics();
        }
        int width = Math.max(1, metrics.widthPixels);
        int height = Math.max(1, metrics.heightPixels);
        return new int[]{width, height};
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (IllegalArgumentException ignored) {
            }
            receiver = null;
        }
        super.onDestroy();
    }
}
