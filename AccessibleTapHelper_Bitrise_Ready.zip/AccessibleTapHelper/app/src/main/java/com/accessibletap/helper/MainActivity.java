package com.accessibletap.helper;

import android.app.Activity;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final String PREFS = "tap_helper_prefs";
    static final String KEY_X = "x_percent";
    static final String KEY_Y = "y_percent";
    static final String KEY_INTERVAL = "interval_ms";
    static final String KEY_SCROLL = "scroll_enabled";
    static final String KEY_MAX = "max_cycles";
    static final String KEY_SWIPE_START = "swipe_start_percent";
    static final String KEY_SWIPE_END = "swipe_end_percent";

    static final String ACTION_START = "com.accessibletap.helper.START";
    static final String ACTION_STOP = "com.accessibletap.helper.STOP";
    static final String ACTION_SINGLE = "com.accessibletap.helper.SINGLE";

    private SharedPreferences prefs;
    private int xPercent;
    private int yPercent;
    private int intervalMs;
    private int maxCycles;
    private int swipeStartPercent;
    private int swipeEndPercent;
    private boolean scrollEnabled;

    private TextView summary;
    private TextView serviceState;
    private CheckBox scrollBox;
    private EditText xInput;
    private EditText yInput;
    private EditText intervalInput;
    private EditText maxCyclesInput;
    private EditText swipeStartInput;
    private EditText swipeEndInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadPrefs();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateServiceState();
    }

    private void loadPrefs() {
        xPercent = prefs.getInt(KEY_X, 50);
        yPercent = prefs.getInt(KEY_Y, 82);
        intervalMs = prefs.getInt(KEY_INTERVAL, 2500);
        scrollEnabled = prefs.getBoolean(KEY_SCROLL, true);
        maxCycles = prefs.getInt(KEY_MAX, 20);
        swipeStartPercent = prefs.getInt(KEY_SWIPE_START, 78);
        swipeEndPercent = prefs.getInt(KEY_SWIPE_END, 35);
    }

    private void savePrefs() {
        prefs.edit()
                .putInt(KEY_X, xPercent)
                .putInt(KEY_Y, yPercent)
                .putInt(KEY_INTERVAL, intervalMs)
                .putBoolean(KEY_SCROLL, scrollEnabled)
                .putInt(KEY_MAX, maxCycles)
                .putInt(KEY_SWIPE_START, swipeStartPercent)
                .putInt(KEY_SWIPE_END, swipeEndPercent)
                .apply();
        updateInputsFromValues();
        updateSummary();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("مساعد النقر الميسر");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setContentDescription("عنوان التطبيق: مساعد النقر الميسر");
        root.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("تطبيق مساعد لإمكانية الوصول. يتيح ضبط موضع نقرة واحدة كنسبة من الشاشة، مع خيار السحب للأعلى بعد النقر، والتحكم من داخل التطبيق أو بأزرار الصوت عند تفعيل خدمة إمكانية الوصول.");
        intro.setTextSize(16);
        intro.setPadding(0, dp(12), 0, dp(12));
        root.addView(intro, matchWrap());

        serviceState = new TextView(this);
        serviceState.setTextSize(18);
        serviceState.setTypeface(Typeface.DEFAULT_BOLD);
        serviceState.setPadding(0, dp(8), 0, dp(8));
        root.addView(serviceState, matchWrap());

        Button settings = bigButton("فتح إعدادات إمكانية الوصول");
        settings.setContentDescription("فتح إعدادات إمكانية الوصول لتفعيل خدمة مساعد النقر الميسر");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings, matchWrap());

        Button refresh = bigButton("تحديث حالة الخدمة");
        refresh.setContentDescription("تحديث حالة خدمة مساعد النقر الميسر");
        refresh.setOnClickListener(v -> updateServiceState());
        root.addView(refresh, matchWrap());

        summary = new TextView(this);
        summary.setTextSize(17);
        summary.setPadding(0, dp(10), 0, dp(12));
        root.addView(summary, matchWrap());

        root.addView(section("إدخال القيم يدويًا"));
        xInput = numberInput("إكس، الموضع الأفقي من صفر إلى مئة", xPercent);
        yInput = numberInput("واي، الموضع العمودي من صفر إلى مئة", yPercent);
        intervalInput = numberInput("الفاصل بالمللي ثانية من 1200 إلى 10000", intervalMs);
        maxCyclesInput = numberInput("عدد الدورات من 1 إلى 200", maxCycles);
        swipeStartInput = numberInput("بداية السحب العمودي من صفر إلى مئة", swipeStartPercent);
        swipeEndInput = numberInput("نهاية السحب العمودي من صفر إلى مئة", swipeEndPercent);
        root.addView(labelAndInput("إكس X بالمئة", xInput));
        root.addView(labelAndInput("واي Y بالمئة", yInput));
        root.addView(labelAndInput("الفاصل بين الدورات بالمللي ثانية", intervalInput));
        root.addView(labelAndInput("عدد الدورات قبل الإيقاف", maxCyclesInput));
        root.addView(labelAndInput("بداية السحب العمودي بالمئة", swipeStartInput));
        root.addView(labelAndInput("نهاية السحب العمودي بالمئة", swipeEndInput));

        Button apply = bigButton("حفظ القيم اليدوية");
        apply.setContentDescription("حفظ القيم اليدوية التي أدخلتها في الخانات");
        apply.setOnClickListener(v -> applyManualValues());
        root.addView(apply, matchWrap());

        root.addView(section("تعديل سريع لموضع النقر"));
        root.addView(row(
                controlButton("إكس أقل خمسة بالمئة", () -> { xPercent = clamp(xPercent - 5, 0, 100); savePrefs(); }),
                controlButton("إكس أكثر خمسة بالمئة", () -> { xPercent = clamp(xPercent + 5, 0, 100); savePrefs(); })
        ));
        root.addView(row(
                controlButton("رفع النقرة خمسة بالمئة", () -> { yPercent = clamp(yPercent - 5, 0, 100); savePrefs(); }),
                controlButton("خفض النقرة خمسة بالمئة", () -> { yPercent = clamp(yPercent + 5, 0, 100); savePrefs(); })
        ));

        root.addView(section("تعديل سريع للتوقيت والعدد"));
        root.addView(row(
                controlButton("أبطأ نصف ثانية", () -> { intervalMs = clamp(intervalMs + 500, 1200, 10000); savePrefs(); }),
                controlButton("أسرع نصف ثانية", () -> { intervalMs = clamp(intervalMs - 500, 1200, 10000); savePrefs(); })
        ));
        root.addView(row(
                controlButton("تقليل العدد خمس دورات", () -> { maxCycles = clamp(maxCycles - 5, 1, 200); savePrefs(); }),
                controlButton("زيادة العدد خمس دورات", () -> { maxCycles = clamp(maxCycles + 5, 1, 200); savePrefs(); })
        ));

        scrollBox = new CheckBox(this);
        scrollBox.setText("تشغيل السحب للأعلى بعد كل نقرة");
        scrollBox.setTextSize(18);
        scrollBox.setChecked(scrollEnabled);
        scrollBox.setContentDescription("تشغيل أو إيقاف السحب للأعلى بعد كل نقرة");
        scrollBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            scrollEnabled = isChecked;
            savePrefs();
        });
        root.addView(scrollBox, matchWrap());

        root.addView(section("أوامر التشغيل"));
        Button single = bigButton("تنفيذ دورة واحدة فقط");
        single.setContentDescription("تنفيذ نقرة واحدة، وإذا كان السحب مفعلًا ينفذ سحبًا واحدًا بعدها");
        single.setOnClickListener(v -> {
            sendCommand(ACTION_SINGLE);
            toast("تم إرسال أمر تنفيذ دورة واحدة. تأكد من تفعيل الخدمة.");
        });
        root.addView(single, matchWrap());

        Button start = bigButton("ابدأ التشغيل المتكرر");
        start.setContentDescription("بدء التشغيل المتكرر. يمكن أيضًا استخدام زر رفع الصوت للتشغيل أو الإيقاف");
        start.setOnClickListener(v -> {
            sendCommand(ACTION_START);
            toast("تم إرسال أمر البدء. إذا لم يعمل، فعّل خدمة إمكانية الوصول أولًا.");
        });
        root.addView(start, matchWrap());

        Button stop = bigButton("إيقاف فورًا");
        stop.setContentDescription("إيقاف النقر فورًا");
        stop.setOnClickListener(v -> {
            sendCommand(ACTION_STOP);
            toast("تم إرسال أمر الإيقاف.");
        });
        root.addView(stop, matchWrap());

        Button openBrowser = bigButton("فتح المتصفح");
        openBrowser.setContentDescription("فتح المتصفح بعد ضبط الإعدادات");
        openBrowser.setOnClickListener(v -> openBrowser());
        root.addView(openBrowser, matchWrap());

        Button reset = bigButton("استعادة الإعدادات الافتراضية");
        reset.setContentDescription("إرجاع كل القيم إلى الإعدادات الافتراضية الآمنة");
        reset.setOnClickListener(v -> resetDefaults());
        root.addView(reset, matchWrap());

        TextView controls = new TextView(this);
        controls.setText("اختصار أزرار الصوت عند تفعيل الخدمة:\nزر رفع الصوت: بدء أو إيقاف التشغيل المتكرر.\nزر خفض الصوت: إيقاف فوري.\nالتطبيق لا يقرأ محتوى الشاشة ولا يطلب صلاحية الإنترنت.");
        controls.setTextSize(16);
        controls.setPadding(0, dp(16), 0, dp(8));
        root.addView(controls, matchWrap());

        TextView safety = new TextView(this);
        safety.setText("تنبيه: استخدم التطبيق كمساعدة شخصية لإمكانية الوصول فقط. لا تستخدمه لتجاوز حماية المواقع أو تنفيذ نشاط مخالف لشروط أي خدمة.");
        safety.setTextSize(15);
        safety.setPadding(0, dp(8), 0, 0);
        root.addView(safety, matchWrap());

        updateInputsFromValues();
        updateSummary();
        updateServiceState();
        setContentView(scroll);
    }

    private void updateInputsFromValues() {
        if (xInput == null) return;
        xInput.setText(String.valueOf(xPercent));
        yInput.setText(String.valueOf(yPercent));
        intervalInput.setText(String.valueOf(intervalMs));
        maxCyclesInput.setText(String.valueOf(maxCycles));
        swipeStartInput.setText(String.valueOf(swipeStartPercent));
        swipeEndInput.setText(String.valueOf(swipeEndPercent));
        if (scrollBox != null && scrollBox.isChecked() != scrollEnabled) {
            scrollBox.setChecked(scrollEnabled);
        }
    }

    private void updateSummary() {
        if (summary == null) return;
        String text = "الإعدادات الحالية:\n" +
                "إكس: " + xPercent + " بالمئة.\n" +
                "واي: " + yPercent + " بالمئة.\n" +
                "الفاصل: " + String.format(Locale.US, "%.1f", intervalMs / 1000.0) + " ثانية.\n" +
                "السحب بعد النقر: " + (scrollEnabled ? "مفعل" : "متوقف") + ".\n" +
                "مسار السحب: من " + swipeStartPercent + " بالمئة إلى " + swipeEndPercent + " بالمئة من ارتفاع الشاشة.\n" +
                "الإيقاف التلقائي بعد: " + maxCycles + " دورة.";
        summary.setText(text);
        summary.setContentDescription(text);
    }

    private void updateServiceState() {
        if (serviceState == null) return;
        boolean enabled = isAccessibilityServiceEnabled();
        String text = enabled ? "حالة الخدمة: مفعلة وجاهزة." : "حالة الخدمة: غير مفعلة. افتح إعدادات إمكانية الوصول ثم فعّل الخدمة.";
        serviceState.setText(text);
        serviceState.setContentDescription(text);
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager != null) {
            List<AccessibilityServiceInfo> enabledServices = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
            ComponentName expected = new ComponentName(this, TapAccessibilityService.class);
            for (AccessibilityServiceInfo serviceInfo : enabledServices) {
                if (serviceInfo.getResolveInfo() != null && serviceInfo.getResolveInfo().serviceInfo != null) {
                    ComponentName actual = new ComponentName(serviceInfo.getResolveInfo().serviceInfo.packageName, serviceInfo.getResolveInfo().serviceInfo.name);
                    if (expected.equals(actual)) return true;
                }
            }
        }
        String flat = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return flat != null && flat.toLowerCase(Locale.US).contains(getPackageName().toLowerCase(Locale.US));
    }

    private void applyManualValues() {
        xPercent = readInt(xInput, xPercent, 0, 100);
        yPercent = readInt(yInput, yPercent, 0, 100);
        intervalMs = readInt(intervalInput, intervalMs, 1200, 10000);
        maxCycles = readInt(maxCyclesInput, maxCycles, 1, 200);
        swipeStartPercent = readInt(swipeStartInput, swipeStartPercent, 0, 100);
        swipeEndPercent = readInt(swipeEndInput, swipeEndPercent, 0, 100);
        if (swipeStartPercent <= swipeEndPercent) {
            swipeStartPercent = 78;
            swipeEndPercent = 35;
            toast("تم تصحيح مسار السحب: البداية يجب أن تكون أسفل النهاية.");
        }
        savePrefs();
        toast("تم حفظ الإعدادات.");
    }

    private int readInt(EditText input, int fallback, int min, int max) {
        try {
            String text = input.getText().toString().trim();
            if (text.isEmpty()) return fallback;
            return clamp(Integer.parseInt(text), min, max);
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private void sendCommand(String action) {
        Intent intent = new Intent(action);
        intent.setPackage(getPackageName());
        sendBroadcast(intent);
    }

    private void openBrowser() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"));
        try {
            startActivity(intent);
        } catch (Exception ex) {
            toast("لم أستطع فتح المتصفح على هذا الجهاز.");
        }
    }

    private void resetDefaults() {
        xPercent = 50;
        yPercent = 82;
        intervalMs = 2500;
        scrollEnabled = true;
        maxCycles = 20;
        swipeStartPercent = 78;
        swipeEndPercent = 35;
        savePrefs();
        toast("تمت استعادة الإعدادات الافتراضية.");
    }

    private LinearLayout labelAndInput(String labelText, EditText input) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(4), 0, dp(4));
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextSize(16);
        label.setContentDescription(labelText);
        box.addView(label, matchWrap());
        box.addView(input, matchWrap());
        return box;
    }

    private EditText numberInput(String hint, int value) {
        EditText editText = new EditText(this);
        editText.setText(String.valueOf(value));
        editText.setHint(hint);
        editText.setTextSize(18);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setSingleLine(true);
        editText.setSelectAllOnFocus(true);
        editText.setContentDescription(hint);
        return editText;
    }

    private TextView section(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(19);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(18), 0, dp(6));
        tv.setContentDescription(text);
        return tv;
    }

    private Button bigButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setMinHeight(dp(56));
        b.setAllCaps(false);
        return b;
    }

    private Button controlButton(String text, Runnable action) {
        Button b = bigButton(text);
        b.setOnClickListener(v -> action.run());
        b.setContentDescription(text);
        return b;
    }

    private LinearLayout row(View left, View right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        int margin = dp(4);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(margin, margin, margin, margin);
        row.addView(left, lp);
        row.addView(right, lp);
        return row;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(5));
        return lp;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }
}
