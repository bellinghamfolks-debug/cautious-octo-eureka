# البناء على Bitrise

## الخيار الأول: استخدام bitrise.yml المرفق
1. ارفع محتويات هذا المشروع إلى GitHub.
2. اربط المستودع في Bitrise.
3. اختر Workflow باسم `primary`.
4. بعد نجاح البناء سيكون ملف APK هنا:
   `AccessibleTapHelper/app/build/outputs/apk/debug/app-debug.apk`

## الخيار الثاني: الإعداد اليدوي داخل Bitrise
- Project Location أو Root Directory:
  `AccessibleTapHelper`
- Module:
  `app`
- Variant:
  `debug`
- Gradle task:
  `:app:assembleDebug`
- قبل البناء أضف خطوة Script:
  `chmod +x AccessibleTapHelper/gradlew`

## ملاحظات
- هذا يبني APK تجريبي Debug، وليس إصدارًا موقّعًا للنشر في متجر Google Play.
- للتثبيت اليدوي على جهازك، استخدم ملف APK الناتج من مجلد debug.
